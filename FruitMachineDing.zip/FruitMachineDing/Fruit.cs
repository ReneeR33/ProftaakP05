﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FruitMachineDing
{
    class Fruit
    {
        public GetfruitInfo(string naam)
        {
            //sql
        }
        public GetCalories(string naam)
        {
            //sql
        }
    }
}
