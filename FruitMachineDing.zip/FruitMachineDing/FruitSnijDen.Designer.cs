﻿namespace FruitMachineDing
{
    partial class FruitSnijden
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.FruitSelectTab = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.BevestigingPanel = new System.Windows.Forms.Panel();
            this.backBtn = new System.Windows.Forms.Button();
            this.persBtn = new System.Windows.Forms.Button();
            this.snijschijfInputLbl = new System.Windows.Forms.Label();
            this.snijschijfLbl = new System.Windows.Forms.Label();
            this.snijschijfBtn = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.selectedFruitLbl = new System.Windows.Forms.Label();
            this.fruitLbl = new System.Windows.Forms.Label();
            this.BevestigKnop = new System.Windows.Forms.Button();
            this.calorieAmtLbl = new System.Windows.Forms.Label();
            this.calorieLbl = new System.Windows.Forms.Label();
            this.vitamineLbx = new System.Windows.Forms.ListBox();
            this.selectedFruitLbx = new System.Windows.Forms.ListBox();
            this.FruitLbx = new System.Windows.Forms.ListBox();
            this.persoonLbl = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label4 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.VerzadigdInputLbl = new System.Windows.Forms.Label();
            this.geslachtInputLbl = new System.Windows.Forms.Label();
            this.leeftijdInputLbl = new System.Windows.Forms.Label();
            this.lichaamstypeInputLbl = new System.Windows.Forms.Label();
            this.NaamInputLbl = new System.Windows.Forms.Label();
            this.VerzadigdLbl = new System.Windows.Forms.Label();
            this.geslachtLbl = new System.Windows.Forms.Label();
            this.leeftijdLbl = new System.Windows.Forms.Label();
            this.lichaamTypeLbl = new System.Windows.Forms.Label();
            this.naamLbl = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.fruitInfoLbl = new System.Windows.Forms.Label();
            this.voedingswaardeInputLbl = new System.Windows.Forms.Label();
            this.voedingswaardeLbl = new System.Windows.Forms.Label();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.fruitInfoLbx = new System.Windows.Forms.ListBox();
            this.FruitSelectTab.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.BevestigingPanel.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.SuspendLayout();
            // 
            // FruitSelectTab
            // 
            this.FruitSelectTab.Controls.Add(this.tabPage1);
            this.FruitSelectTab.Controls.Add(this.tabPage2);
            this.FruitSelectTab.Controls.Add(this.tabPage3);
            this.FruitSelectTab.Location = new System.Drawing.Point(0, 0);
            this.FruitSelectTab.Name = "FruitSelectTab";
            this.FruitSelectTab.SelectedIndex = 0;
            this.FruitSelectTab.Size = new System.Drawing.Size(901, 467);
            this.FruitSelectTab.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.BevestigingPanel);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.selectedFruitLbl);
            this.tabPage1.Controls.Add(this.fruitLbl);
            this.tabPage1.Controls.Add(this.BevestigKnop);
            this.tabPage1.Controls.Add(this.calorieAmtLbl);
            this.tabPage1.Controls.Add(this.calorieLbl);
            this.tabPage1.Controls.Add(this.vitamineLbx);
            this.tabPage1.Controls.Add(this.selectedFruitLbx);
            this.tabPage1.Controls.Add(this.FruitLbx);
            this.tabPage1.Controls.Add(this.persoonLbl);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(893, 438);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Porties";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // BevestigingPanel
            // 
            this.BevestigingPanel.Controls.Add(this.backBtn);
            this.BevestigingPanel.Controls.Add(this.persBtn);
            this.BevestigingPanel.Controls.Add(this.snijschijfInputLbl);
            this.BevestigingPanel.Controls.Add(this.snijschijfLbl);
            this.BevestigingPanel.Controls.Add(this.snijschijfBtn);
            this.BevestigingPanel.Location = new System.Drawing.Point(422, 151);
            this.BevestigingPanel.Name = "BevestigingPanel";
            this.BevestigingPanel.Size = new System.Drawing.Size(893, 438);
            this.BevestigingPanel.TabIndex = 1;
            this.BevestigingPanel.Visible = false;
            this.BevestigingPanel.VisibleChanged += new System.EventHandler(this.BevestigingPanel_VisibleChanged);
            // 
            // backBtn
            // 
            this.backBtn.Location = new System.Drawing.Point(18, 106);
            this.backBtn.Name = "backBtn";
            this.backBtn.Size = new System.Drawing.Size(144, 30);
            this.backBtn.TabIndex = 8;
            this.backBtn.Text = "ga terug";
            this.backBtn.UseVisualStyleBackColor = true;
            this.backBtn.Click += new System.EventHandler(this.backBtn_Click);
            // 
            // persBtn
            // 
            this.persBtn.Location = new System.Drawing.Point(18, 75);
            this.persBtn.Name = "persBtn";
            this.persBtn.Size = new System.Drawing.Size(144, 25);
            this.persBtn.TabIndex = 7;
            this.persBtn.Text = "pers";
            this.persBtn.UseVisualStyleBackColor = true;
            // 
            // snijschijfInputLbl
            // 
            this.snijschijfInputLbl.AutoSize = true;
            this.snijschijfInputLbl.Location = new System.Drawing.Point(136, 25);
            this.snijschijfInputLbl.Name = "snijschijfInputLbl";
            this.snijschijfInputLbl.Size = new System.Drawing.Size(111, 17);
            this.snijschijfInputLbl.TabIndex = 6;
            this.snijschijfInputLbl.Text = "huidige snijschijf";
            // 
            // snijschijfLbl
            // 
            this.snijschijfLbl.AutoSize = true;
            this.snijschijfLbl.Location = new System.Drawing.Point(15, 24);
            this.snijschijfLbl.Name = "snijschijfLbl";
            this.snijschijfLbl.Size = new System.Drawing.Size(115, 17);
            this.snijschijfLbl.TabIndex = 5;
            this.snijschijfLbl.Text = "huidige snijschijf:";
            // 
            // snijschijfBtn
            // 
            this.snijschijfBtn.Location = new System.Drawing.Point(18, 44);
            this.snijschijfBtn.Name = "snijschijfBtn";
            this.snijschijfBtn.Size = new System.Drawing.Size(144, 25);
            this.snijschijfBtn.TabIndex = 4;
            this.snijschijfBtn.Text = "verander snijschijf";
            this.snijschijfBtn.UseVisualStyleBackColor = true;
            this.snijschijfBtn.Click += new System.EventHandler(this.snijschijfBtn_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(579, 41);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 17);
            this.label3.TabIndex = 9;
            this.label3.Text = "Vitamines:";
            // 
            // selectedFruitLbl
            // 
            this.selectedFruitLbl.AutoSize = true;
            this.selectedFruitLbl.Location = new System.Drawing.Point(292, 41);
            this.selectedFruitLbl.Name = "selectedFruitLbl";
            this.selectedFruitLbl.Size = new System.Drawing.Size(125, 17);
            this.selectedFruitLbl.TabIndex = 8;
            this.selectedFruitLbl.Text = "Geselecteerd fruit:";
            this.selectedFruitLbl.Click += new System.EventHandler(this.selectedFruit_Click);
            // 
            // fruitLbl
            // 
            this.fruitLbl.AutoSize = true;
            this.fruitLbl.Location = new System.Drawing.Point(6, 41);
            this.fruitLbl.Name = "fruitLbl";
            this.fruitLbl.Size = new System.Drawing.Size(36, 17);
            this.fruitLbl.TabIndex = 7;
            this.fruitLbl.Text = "fruit:";
            // 
            // BevestigKnop
            // 
            this.BevestigKnop.Location = new System.Drawing.Point(701, 400);
            this.BevestigKnop.Name = "BevestigKnop";
            this.BevestigKnop.Size = new System.Drawing.Size(131, 26);
            this.BevestigKnop.TabIndex = 6;
            this.BevestigKnop.Text = "bevestig";
            this.BevestigKnop.UseVisualStyleBackColor = true;
            this.BevestigKnop.Click += new System.EventHandler(this.BevestigKnop_Click);
            // 
            // calorieAmtLbl
            // 
            this.calorieAmtLbl.AutoSize = true;
            this.calorieAmtLbl.Location = new System.Drawing.Point(649, 3);
            this.calorieAmtLbl.Name = "calorieAmtLbl";
            this.calorieAmtLbl.Size = new System.Drawing.Size(31, 17);
            this.calorieAmtLbl.TabIndex = 5;
            this.calorieAmtLbl.Text = "test";
            // 
            // calorieLbl
            // 
            this.calorieLbl.AutoSize = true;
            this.calorieLbl.Location = new System.Drawing.Point(579, 3);
            this.calorieLbl.Name = "calorieLbl";
            this.calorieLbl.Size = new System.Drawing.Size(64, 17);
            this.calorieLbl.TabIndex = 4;
            this.calorieLbl.Text = "Caloriën:";
            // 
            // vitamineLbx
            // 
            this.vitamineLbx.FormattingEnabled = true;
            this.vitamineLbx.ItemHeight = 16;
            this.vitamineLbx.Location = new System.Drawing.Point(582, 70);
            this.vitamineLbx.Name = "vitamineLbx";
            this.vitamineLbx.Size = new System.Drawing.Size(250, 324);
            this.vitamineLbx.TabIndex = 3;
            // 
            // selectedFruitLbx
            // 
            this.selectedFruitLbx.FormattingEnabled = true;
            this.selectedFruitLbx.ItemHeight = 16;
            this.selectedFruitLbx.Location = new System.Drawing.Point(295, 70);
            this.selectedFruitLbx.Name = "selectedFruitLbx";
            this.selectedFruitLbx.Size = new System.Drawing.Size(250, 356);
            this.selectedFruitLbx.TabIndex = 2;
            this.selectedFruitLbx.SelectedIndexChanged += new System.EventHandler(this.selectedFruitLbx_SelectedIndexChanged);
            // 
            // FruitLbx
            // 
            this.FruitLbx.FormattingEnabled = true;
            this.FruitLbx.ItemHeight = 16;
            this.FruitLbx.Location = new System.Drawing.Point(6, 70);
            this.FruitLbx.Name = "FruitLbx";
            this.FruitLbx.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.FruitLbx.Size = new System.Drawing.Size(250, 356);
            this.FruitLbx.TabIndex = 1;
            this.FruitLbx.SelectedIndexChanged += new System.EventHandler(this.FruitLbx_SelectedIndexChanged);
            this.FruitLbx.VisibleChanged += new System.EventHandler(this.FruitLbx_VisibleChanged);
            // 
            // persoonLbl
            // 
            this.persoonLbl.AutoSize = true;
            this.persoonLbl.Location = new System.Drawing.Point(8, 3);
            this.persoonLbl.Name = "persoonLbl";
            this.persoonLbl.Size = new System.Drawing.Size(61, 17);
            this.persoonLbl.TabIndex = 0;
            this.persoonLbl.Text = "Persoon";
            this.persoonLbl.Click += new System.EventHandler(this.persoonLbl_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.button1);
            this.tabPage2.Controls.Add(this.VerzadigdInputLbl);
            this.tabPage2.Controls.Add(this.geslachtInputLbl);
            this.tabPage2.Controls.Add(this.leeftijdInputLbl);
            this.tabPage2.Controls.Add(this.lichaamstypeInputLbl);
            this.tabPage2.Controls.Add(this.NaamInputLbl);
            this.tabPage2.Controls.Add(this.VerzadigdLbl);
            this.tabPage2.Controls.Add(this.geslachtLbl);
            this.tabPage2.Controls.Add(this.leeftijdLbl);
            this.tabPage2.Controls.Add(this.lichaamTypeLbl);
            this.tabPage2.Controls.Add(this.naamLbl);
            this.tabPage2.Controls.Add(this.listBox1);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(893, 438);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Personen";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 50);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 17);
            this.label4.TabIndex = 12;
            this.label4.Text = "personen:";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(300, 394);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(101, 32);
            this.button1.TabIndex = 11;
            this.button1.Text = "log in";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // VerzadigdInputLbl
            // 
            this.VerzadigdInputLbl.AccessibleRole = System.Windows.Forms.AccessibleRole.IpAddress;
            this.VerzadigdInputLbl.AutoSize = true;
            this.VerzadigdInputLbl.Location = new System.Drawing.Point(392, 181);
            this.VerzadigdInputLbl.Name = "VerzadigdInputLbl";
            this.VerzadigdInputLbl.Size = new System.Drawing.Size(31, 17);
            this.VerzadigdInputLbl.TabIndex = 10;
            this.VerzadigdInputLbl.Text = "test";
            // 
            // geslachtInputLbl
            // 
            this.geslachtInputLbl.AccessibleRole = System.Windows.Forms.AccessibleRole.IpAddress;
            this.geslachtInputLbl.AutoSize = true;
            this.geslachtInputLbl.Location = new System.Drawing.Point(392, 155);
            this.geslachtInputLbl.Name = "geslachtInputLbl";
            this.geslachtInputLbl.Size = new System.Drawing.Size(31, 17);
            this.geslachtInputLbl.TabIndex = 9;
            this.geslachtInputLbl.Text = "test";
            // 
            // leeftijdInputLbl
            // 
            this.leeftijdInputLbl.AccessibleRole = System.Windows.Forms.AccessibleRole.IpAddress;
            this.leeftijdInputLbl.AutoSize = true;
            this.leeftijdInputLbl.Location = new System.Drawing.Point(392, 127);
            this.leeftijdInputLbl.Name = "leeftijdInputLbl";
            this.leeftijdInputLbl.Size = new System.Drawing.Size(31, 17);
            this.leeftijdInputLbl.TabIndex = 8;
            this.leeftijdInputLbl.Text = "test";
            // 
            // lichaamstypeInputLbl
            // 
            this.lichaamstypeInputLbl.AccessibleRole = System.Windows.Forms.AccessibleRole.IpAddress;
            this.lichaamstypeInputLbl.AutoSize = true;
            this.lichaamstypeInputLbl.Location = new System.Drawing.Point(392, 98);
            this.lichaamstypeInputLbl.Name = "lichaamstypeInputLbl";
            this.lichaamstypeInputLbl.Size = new System.Drawing.Size(31, 17);
            this.lichaamstypeInputLbl.TabIndex = 7;
            this.lichaamstypeInputLbl.Text = "test";
            // 
            // NaamInputLbl
            // 
            this.NaamInputLbl.AccessibleRole = System.Windows.Forms.AccessibleRole.IpAddress;
            this.NaamInputLbl.AutoSize = true;
            this.NaamInputLbl.Location = new System.Drawing.Point(392, 70);
            this.NaamInputLbl.Name = "NaamInputLbl";
            this.NaamInputLbl.Size = new System.Drawing.Size(31, 17);
            this.NaamInputLbl.TabIndex = 6;
            this.NaamInputLbl.Text = "test";
            // 
            // VerzadigdLbl
            // 
            this.VerzadigdLbl.AutoSize = true;
            this.VerzadigdLbl.Location = new System.Drawing.Point(297, 181);
            this.VerzadigdLbl.Name = "VerzadigdLbl";
            this.VerzadigdLbl.Size = new System.Drawing.Size(80, 17);
            this.VerzadigdLbl.TabIndex = 5;
            this.VerzadigdLbl.Text = "Verzadigd?";
            // 
            // geslachtLbl
            // 
            this.geslachtLbl.AutoSize = true;
            this.geslachtLbl.Location = new System.Drawing.Point(297, 155);
            this.geslachtLbl.Name = "geslachtLbl";
            this.geslachtLbl.Size = new System.Drawing.Size(68, 17);
            this.geslachtLbl.TabIndex = 4;
            this.geslachtLbl.Text = "Geslacht:";
            // 
            // leeftijdLbl
            // 
            this.leeftijdLbl.AutoSize = true;
            this.leeftijdLbl.Location = new System.Drawing.Point(297, 127);
            this.leeftijdLbl.Name = "leeftijdLbl";
            this.leeftijdLbl.Size = new System.Drawing.Size(58, 17);
            this.leeftijdLbl.TabIndex = 3;
            this.leeftijdLbl.Text = "Leeftijd:";
            // 
            // lichaamTypeLbl
            // 
            this.lichaamTypeLbl.AutoSize = true;
            this.lichaamTypeLbl.Location = new System.Drawing.Point(297, 98);
            this.lichaamTypeLbl.Name = "lichaamTypeLbl";
            this.lichaamTypeLbl.Size = new System.Drawing.Size(99, 17);
            this.lichaamTypeLbl.TabIndex = 2;
            this.lichaamTypeLbl.Text = "Lichaamstype:";
            // 
            // naamLbl
            // 
            this.naamLbl.AutoSize = true;
            this.naamLbl.Location = new System.Drawing.Point(297, 70);
            this.naamLbl.Name = "naamLbl";
            this.naamLbl.Size = new System.Drawing.Size(49, 17);
            this.naamLbl.TabIndex = 1;
            this.naamLbl.Text = "Naam:";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Location = new System.Drawing.Point(8, 70);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(254, 356);
            this.listBox1.TabIndex = 0;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.fruitInfoLbl);
            this.tabPage3.Controls.Add(this.voedingswaardeInputLbl);
            this.tabPage3.Controls.Add(this.voedingswaardeLbl);
            this.tabPage3.Controls.Add(this.listBox2);
            this.tabPage3.Controls.Add(this.fruitInfoLbx);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(893, 438);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Fruit info";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // fruitInfoLbl
            // 
            this.fruitInfoLbl.AutoSize = true;
            this.fruitInfoLbl.Location = new System.Drawing.Point(554, 70);
            this.fruitInfoLbl.Name = "fruitInfoLbl";
            this.fruitInfoLbl.Size = new System.Drawing.Size(31, 17);
            this.fruitInfoLbl.TabIndex = 6;
            this.fruitInfoLbl.Text = "test";
            // 
            // voedingswaardeInputLbl
            // 
            this.voedingswaardeInputLbl.AutoSize = true;
            this.voedingswaardeInputLbl.Location = new System.Drawing.Point(674, 38);
            this.voedingswaardeInputLbl.Name = "voedingswaardeInputLbl";
            this.voedingswaardeInputLbl.Size = new System.Drawing.Size(31, 17);
            this.voedingswaardeInputLbl.TabIndex = 5;
            this.voedingswaardeInputLbl.Text = "test";
            // 
            // voedingswaardeLbl
            // 
            this.voedingswaardeLbl.AutoSize = true;
            this.voedingswaardeLbl.Location = new System.Drawing.Point(551, 38);
            this.voedingswaardeLbl.Name = "voedingswaardeLbl";
            this.voedingswaardeLbl.Size = new System.Drawing.Size(117, 17);
            this.voedingswaardeLbl.TabIndex = 4;
            this.voedingswaardeLbl.Text = "Voedingswaarde:";
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.ItemHeight = 16;
            this.listBox2.Location = new System.Drawing.Point(264, 38);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(250, 388);
            this.listBox2.TabIndex = 3;
            // 
            // fruitInfoLbx
            // 
            this.fruitInfoLbx.FormattingEnabled = true;
            this.fruitInfoLbx.ItemHeight = 16;
            this.fruitInfoLbx.Location = new System.Drawing.Point(8, 38);
            this.fruitInfoLbx.Name = "fruitInfoLbx";
            this.fruitInfoLbx.Size = new System.Drawing.Size(250, 388);
            this.fruitInfoLbx.TabIndex = 2;
            // 
            // FruitSnijden
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(901, 463);
            this.Controls.Add(this.FruitSelectTab);
            this.MaximumSize = new System.Drawing.Size(919, 510);
            this.MinimumSize = new System.Drawing.Size(919, 510);
            this.Name = "FruitSnijden";
            this.Text = "Fruit snijden";
            this.FruitSelectTab.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.BevestigingPanel.ResumeLayout(false);
            this.BevestigingPanel.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl FruitSelectTab;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ListBox vitamineLbx;
        private System.Windows.Forms.ListBox selectedFruitLbx;
        private System.Windows.Forms.ListBox FruitLbx;
        private System.Windows.Forms.Label persoonLbl;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label calorieAmtLbl;
        private System.Windows.Forms.Label calorieLbl;
        private System.Windows.Forms.Button BevestigKnop;
        private System.Windows.Forms.Label VerzadigdInputLbl;
        private System.Windows.Forms.Label geslachtInputLbl;
        private System.Windows.Forms.Label leeftijdInputLbl;
        private System.Windows.Forms.Label lichaamstypeInputLbl;
        private System.Windows.Forms.Label NaamInputLbl;
        private System.Windows.Forms.Label VerzadigdLbl;
        private System.Windows.Forms.Label geslachtLbl;
        private System.Windows.Forms.Label leeftijdLbl;
        private System.Windows.Forms.Label lichaamTypeLbl;
        private System.Windows.Forms.Label naamLbl;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label fruitInfoLbl;
        private System.Windows.Forms.Label voedingswaardeInputLbl;
        private System.Windows.Forms.Label voedingswaardeLbl;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.ListBox fruitInfoLbx;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label selectedFruitLbl;
        private System.Windows.Forms.Label fruitLbl;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel BevestigingPanel;
        private System.Windows.Forms.Button backBtn;
        private System.Windows.Forms.Button persBtn;
        private System.Windows.Forms.Label snijschijfInputLbl;
        private System.Windows.Forms.Label snijschijfLbl;
        private System.Windows.Forms.Button snijschijfBtn;
    }
}

